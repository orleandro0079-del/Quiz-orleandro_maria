import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Milk, Award } from "lucide-react";

export default function Home() {
  const [participantName, setParticipantName] = useState("");
  const [, setLocation] = useLocation();

  const handleStart = () => {
    if (participantName.trim()) {
      setLocation(`/quiz?name=${encodeURIComponent(participantName.trim())}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && participantName.trim()) {
      handleStart();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-lg mb-6">
            <Milk className="w-10 h-10 text-orange-500" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">
            Quiz: Creme de Leite e Requeijão
          </h1>
          <p className="text-lg text-muted-foreground">
            Tecnologia em Alimentos - Dinâmica Interativa
          </p>
        </div>

        <Card className="shadow-2xl border-2">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl flex items-center justify-center gap-2">
              <Award className="w-6 h-6 text-primary" />
              Bem-vindo à Competição!
            </CardTitle>
            <CardDescription className="text-base mt-2">
              Teste seus conhecimentos sobre laticínios em tempo real com outros participantes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium text-foreground">
                Digite seu nome para começar:
              </label>
              <Input
                id="name"
                type="text"
                placeholder="Seu nome completo"
                value={participantName}
                onChange={(e) => setParticipantName(e.target.value)}
                onKeyPress={handleKeyPress}
                className="text-lg h-12"
                maxLength={255}
                autoFocus
              />
            </div>

            <Button
              onClick={handleStart}
              disabled={!participantName.trim()}
              size="lg"
              className="w-full h-14 text-lg font-semibold"
            >
              Entrar na Competição
            </Button>

            <div className="bg-muted/50 rounded-lg p-4 space-y-2 text-sm text-muted-foreground">
              <p className="font-semibold text-foreground">Como funciona:</p>
              <ul className="space-y-1 list-disc list-inside">
                <li>Responda perguntas de múltipla escolha</li>
                <li>Verde = acertou | Vermelho = errou</li>
                <li>Acompanhe o ranking em tempo real</li>
                <li>Veja sua pontuação final ao terminar</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Boa sorte! 🧀🥛
        </p>
      </div>
    </div>
  );
}
