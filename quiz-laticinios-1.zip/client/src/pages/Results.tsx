import { useMemo, useEffect } from "react";
import { useSearch, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Trophy, Medal, Award, Home } from "lucide-react";

export default function Results() {
  const search = useSearch();
  const [, setLocation] = useLocation();
  const params = useMemo(() => new URLSearchParams(search), [search]);
  const sessionIdParam = params.get("sessionId");
  const sessionId = sessionIdParam ? parseInt(sessionIdParam) : null;

  const { data: allSessions, isLoading } = trpc.quiz.getAllSessions.useQuery();

  useEffect(() => {
    if (!sessionId) {
      setLocation("/");
    }
  }, [sessionId, setLocation]);

  if (isLoading || !allSessions || !sessionId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  const currentSession = allSessions.find((s) => s.id === sessionId);
  const completedSessions = allSessions.filter((s) => s.isCompleted);
  const sortedSessions = [...completedSessions].sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return new Date(a.completedAt!).getTime() - new Date(b.completedAt!).getTime();
  });

  const userRank = sortedSessions.findIndex((s) => s.id === sessionId) + 1;
  const totalParticipants = sortedSessions.length;

  const getPerformanceMessage = (score: number, totalQuestions: number) => {
    const percentage = (score / totalQuestions) * 100;
    if (percentage === 100) return "Perfeito! 🎉";
    if (percentage >= 80) return "Excelente! 🌟";
    if (percentage >= 60) return "Muito bom! 👏";
    if (percentage >= 40) return "Bom trabalho! 👍";
    return "Continue praticando! 💪";
  };

  if (!currentSession) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="mb-4">Sessão não encontrada</p>
            <Button onClick={() => setLocation("/")}>Voltar ao Início</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalQuestions = currentSession.currentQuestionIndex;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-4 py-8">
      <div className="container max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-lg mb-4">
            <Trophy className="w-10 h-10 text-yellow-500" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">
            Quiz Finalizado!
          </h1>
          <p className="text-lg text-muted-foreground">
            Confira seu desempenho e o ranking final
          </p>
        </div>

        {/* User Score Card */}
        <Card className="border-2 border-primary shadow-2xl">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl">Seu Resultado</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-6xl font-bold text-primary mb-2">
                {currentSession.score}/{totalQuestions}
              </div>
              <p className="text-xl text-muted-foreground">
                {getPerformanceMessage(currentSession.score, totalQuestions)}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Sua Posição</p>
                <p className="text-3xl font-bold text-foreground">
                  {userRank}º
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Participantes</p>
                <p className="text-3xl font-bold text-foreground">
                  {totalParticipants}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Leaderboard */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-6 h-6 text-primary" />
              Ranking Final
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {sortedSessions.map((session, index) => {
                const isCurrentUser = session.id === sessionId;
                const medal =
                  index === 0 ? (
                    <Trophy className="w-6 h-6 text-yellow-500" />
                  ) : index === 1 ? (
                    <Medal className="w-6 h-6 text-gray-400" />
                  ) : index === 2 ? (
                    <Medal className="w-6 h-6 text-orange-600" />
                  ) : null;

                return (
                  <div
                    key={session.id}
                    className={`flex items-center gap-4 p-4 rounded-lg ${
                      isCurrentUser
                        ? "bg-primary/10 border-2 border-primary"
                        : index < 3
                        ? "bg-muted/70"
                        : "bg-muted/40"
                    }`}
                  >
                    <div className="flex-shrink-0 w-10 text-center">
                      {medal || (
                        <span className="text-xl font-bold text-muted-foreground">
                          {index + 1}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground truncate">
                        {session.participantName}
                        {isCurrentUser && " (você)"}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {session.score} de {totalQuestions} acertos •{" "}
                        {Math.round((session.score / totalQuestions) * 100)}%
                      </p>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <p className="text-2xl font-bold text-primary">
                        {session.score}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex justify-center">
          <Button
            onClick={() => setLocation("/")}
            size="lg"
            className="gap-2"
          >
            <Home className="w-5 h-5" />
            Voltar ao Início
          </Button>
        </div>
      </div>
    </div>
  );
}
