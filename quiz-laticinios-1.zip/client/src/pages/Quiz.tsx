import { useState, useEffect, useMemo } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Trophy, Users } from "lucide-react";
import { toast } from "sonner";

const CATEGORY_INFO = {
  legislacao: { label: "Legislação", icon: "⚖️" },
  processo_requeijao: { label: "Processo - Requeijão", icon: "🧈" },
  processo_creme: { label: "Processo - Creme de Leite", icon: "🥛" },
  composicao: { label: "Composição", icon: "🧬" },
  microbiologia: { label: "Microbiologia", icon: "🔬" },
  armazenamento: { label: "Armazenamento", icon: "❄️" },
};

export default function Quiz() {
  const search = useSearch();
  const [, setLocation] = useLocation();
  const params = useMemo(() => new URLSearchParams(search), [search]);
  const participantName = params.get("name");

  const [sessionId, setSessionId] = useState<number | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: questions, isLoading: questionsLoading } = trpc.quiz.getQuestions.useQuery();
  const { data: leaderboard } = trpc.quiz.getLeaderboard.useQuery(undefined, {
    refetchInterval: 2000, // Update every 2 seconds
  });

  const startSessionMutation = trpc.quiz.startSession.useMutation();
  const submitAnswerMutation = trpc.quiz.submitAnswer.useMutation();
  const completeSessionMutation = trpc.quiz.completeSession.useMutation();

  // Redirect if no name
  useEffect(() => {
    if (!participantName) {
      setLocation("/");
    }
  }, [participantName, setLocation]);

  // Start session
  useEffect(() => {
    if (participantName && !sessionId && !startSessionMutation.isPending) {
      startSessionMutation.mutate(
        { participantName },
        {
          onSuccess: (data) => {
            setSessionId(data.sessionId);
          },
          onError: () => {
            toast.error("Erro ao iniciar sessão");
            setLocation("/");
          },
        }
      );
    }
  }, [participantName, sessionId, startSessionMutation, setLocation]);

  if (!participantName || questionsLoading || !questions || !sessionId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const totalQuestions = questions.length;
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;

  const handleAnswerClick = async (answerId: number) => {
    if (isSubmitting || selectedAnswer !== null) return;

    setSelectedAnswer(answerId);
    setIsSubmitting(true);

    try {
      const result = await submitAnswerMutation.mutateAsync({
        sessionId,
        questionId: currentQuestion.id,
        answerId,
      });

      setFeedback(result.isCorrect ? "correct" : "incorrect");

      // Wait for animation
      setTimeout(() => {
        if (currentQuestionIndex + 1 < totalQuestions) {
          // Next question
          setCurrentQuestionIndex(currentQuestionIndex + 1);
          setSelectedAnswer(null);
          setFeedback(null);
          setIsSubmitting(false);
        } else {
          // Quiz completed
          completeSessionMutation.mutate(
            { sessionId },
            {
              onSuccess: () => {
                setLocation(`/results?sessionId=${sessionId}`);
              },
            }
          );
        }
      }, 1500);
    } catch (error) {
      toast.error("Erro ao enviar resposta");
      setIsSubmitting(false);
      setSelectedAnswer(null);
    }
  };

  const categoryClass = `category-${currentQuestion.category}`;
  const categoryInfo = CATEGORY_INFO[currentQuestion.category];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-4">
      <div className="container max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Main Quiz Area */}
          <div className="lg:col-span-2 space-y-4">
            {/* Progress */}
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Pergunta {currentQuestionIndex + 1} de {totalQuestions}</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Question Card */}
            <Card className={`${categoryClass} border-l-4 shadow-lg`}>
              <CardHeader>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                  <span>{categoryInfo.icon}</span>
                  <span className="font-medium">{categoryInfo.label}</span>
                </div>
                <CardTitle className="text-xl md:text-2xl leading-relaxed">
                  {currentQuestion.text}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {currentQuestion.answers.map((answer) => {
                  const isSelected = selectedAnswer === answer.id;
                  const feedbackClass = isSelected
                    ? feedback === "correct"
                      ? "answer-correct"
                      : feedback === "incorrect"
                      ? "answer-incorrect"
                      : ""
                    : "";

                  return (
                    <Button
                      key={answer.id}
                      onClick={() => handleAnswerClick(answer.id)}
                      disabled={isSubmitting || selectedAnswer !== null}
                      variant="outline"
                      className={`w-full h-auto min-h-[3rem] text-left justify-start p-4 text-base md:text-lg whitespace-normal ${feedbackClass}`}
                    >
                      {answer.text}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4 shadow-lg">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  Ranking ao Vivo
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboard && leaderboard.length > 0 ? (
                  <div className="space-y-2">
                    {leaderboard.slice(0, 10).map((session, index) => (
                      <div
                        key={session.id}
                        className={`flex items-center gap-3 p-3 rounded-lg ${
                          session.id === sessionId
                            ? "bg-primary/10 border-2 border-primary"
                            : "bg-muted/50"
                        }`}
                      >
                        <div
                          className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                            index === 0
                              ? "bg-yellow-400 text-yellow-900"
                              : index === 1
                              ? "bg-gray-300 text-gray-700"
                              : index === 2
                              ? "bg-orange-400 text-orange-900"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate text-sm">
                            {session.participantName}
                            {session.id === sessionId && " (você)"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {session.score} acertos • {session.currentQuestionIndex}/{totalQuestions}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Aguardando participantes...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
