# Quiz Laticínios - TODO

## Protótipo (2 perguntas de exemplo)

- [x] Criar schema do banco de dados para quiz multiplayer
- [x] Implementar sistema de perguntas com categorias temáticas
- [x] Criar tela inicial com entrada de nome do participante
- [x] Desenvolver interface de quiz com feedback visual (verde/vermelho)
- [x] Implementar ranking em tempo real
- [x] Criar tela de resultados final
- [x] Adicionar 2 perguntas de exemplo (1 sobre legislação, 1 sobre processo)
- [x] Aplicar design adaptativo por tema de pergunta
- [x] Garantir responsividade mobile
- [x] Testar sistema multiplayer
