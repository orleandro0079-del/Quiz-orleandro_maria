import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  quiz: router({
    // Get all questions with their answers
    getQuestions: publicProcedure.query(async () => {
      const allQuestions = await db.getAllQuestions();
      const questionsWithAnswers = await Promise.all(
        allQuestions.map(async (q) => {
          const questionAnswers = await db.getAnswersForQuestion(q.id);
          // Don't send isCorrect to client
          const sanitizedAnswers = questionAnswers.map(({ id, text, orderIndex }) => ({
            id,
            text,
            orderIndex,
          }));
          return {
            ...q,
            answers: sanitizedAnswers,
          };
        })
      );
      return questionsWithAnswers;
    }),

    // Create a new quiz session
    startSession: publicProcedure
      .input(z.object({
        participantName: z.string().min(1).max(255),
      }))
      .mutation(async ({ input }) => {
        const sessionId = await db.createQuizSession(input.participantName);
        return { sessionId };
      }),

    // Submit an answer
    submitAnswer: publicProcedure
      .input(z.object({
        sessionId: z.number(),
        questionId: z.number(),
        answerId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const result = await db.submitAnswer(
          input.sessionId,
          input.questionId,
          input.answerId
        );
        return result;
      }),

    // Get leaderboard (all active sessions)
    getLeaderboard: publicProcedure.query(async () => {
      const sessions = await db.getActiveQuizSessions();
      return sessions;
    }),

    // Get all sessions (including completed)
    getAllSessions: publicProcedure.query(async () => {
      const sessions = await db.getAllQuizSessions();
      return sessions;
    }),

    // Complete a quiz session
    completeSession: publicProcedure
      .input(z.object({
        sessionId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.completeQuizSession(input.sessionId);
        return { success: true };
      }),

    // Seed questions (for demo purposes)
    seedQuestions: publicProcedure
      .input(z.array(z.object({
        text: z.string(),
        category: z.enum([
          "legislacao",
          "processo_requeijao",
          "processo_creme",
          "composicao",
          "microbiologia",
          "armazenamento"
        ]),
        answers: z.array(z.object({
          text: z.string(),
          isCorrect: z.boolean(),
        })),
      })))
      .mutation(async ({ input }) => {
        await db.seedQuestions(input);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
