import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  questions, 
  answers, 
  quizSessions, 
  userResponses,
  InsertQuestion,
  InsertAnswer,
  InsertQuizSession,
  InsertUserResponse
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Quiz-specific queries

export async function getAllQuestions() {
  const db = await getDb();
  if (!db) return [];
  
  const allQuestions = await db.select().from(questions).orderBy(questions.orderIndex);
  return allQuestions;
}

export async function getAnswersForQuestion(questionId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const questionAnswers = await db
    .select()
    .from(answers)
    .where(eq(answers.questionId, questionId))
    .orderBy(answers.orderIndex);
  
  return questionAnswers;
}

export async function createQuizSession(participantName: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(quizSessions).values({
    participantName,
    currentQuestionIndex: 0,
    score: 0,
    isCompleted: false,
  });
  
  return result[0].insertId;
}

export async function getActiveQuizSessions() {
  const db = await getDb();
  if (!db) return [];
  
  const sessions = await db
    .select()
    .from(quizSessions)
    .where(eq(quizSessions.isCompleted, false))
    .orderBy(desc(quizSessions.score), desc(quizSessions.currentQuestionIndex));
  
  return sessions;
}

export async function getAllQuizSessions() {
  const db = await getDb();
  if (!db) return [];
  
  const sessions = await db
    .select()
    .from(quizSessions)
    .orderBy(desc(quizSessions.score), desc(quizSessions.createdAt));
  
  return sessions;
}

export async function getQuizSession(sessionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(quizSessions)
    .where(eq(quizSessions.id, sessionId))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function submitAnswer(sessionId: number, questionId: number, answerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Check if answer is correct
  const answer = await db
    .select()
    .from(answers)
    .where(eq(answers.id, answerId))
    .limit(1);
  
  if (answer.length === 0) {
    throw new Error("Answer not found");
  }
  
  const isCorrect = answer[0].isCorrect;
  
  // Record the response
  await db.insert(userResponses).values({
    sessionId,
    questionId,
    answerId,
    isCorrect,
  });
  
  // Update session
  const session = await getQuizSession(sessionId);
  if (!session) throw new Error("Session not found");
  
  const newScore = isCorrect ? session.score + 1 : session.score;
  const newQuestionIndex = session.currentQuestionIndex + 1;
  
  await db
    .update(quizSessions)
    .set({
      score: newScore,
      currentQuestionIndex: newQuestionIndex,
    })
    .where(eq(quizSessions.id, sessionId));
  
  return { isCorrect, newScore, newQuestionIndex };
}

export async function completeQuizSession(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(quizSessions)
    .set({
      isCompleted: true,
      completedAt: new Date(),
    })
    .where(eq(quizSessions.id, sessionId));
}

export async function seedQuestions(questionsData: Array<{
  text: string;
  category: "legislacao" | "processo_requeijao" | "processo_creme" | "composicao" | "microbiologia" | "armazenamento";
  answers: Array<{ text: string; isCorrect: boolean }>;
}>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Clear existing data
  await db.delete(userResponses);
  await db.delete(answers);
  await db.delete(questions);
  
  // Insert questions and answers
  for (let i = 0; i < questionsData.length; i++) {
    const q = questionsData[i];
    const result = await db.insert(questions).values({
      text: q.text,
      category: q.category,
      orderIndex: i,
    });
    
    const questionId = result[0].insertId;
    
    for (let j = 0; j < q.answers.length; j++) {
      await db.insert(answers).values({
        questionId,
        text: q.answers[j].text,
        isCorrect: q.answers[j].isCorrect,
        orderIndex: j,
      });
    }
  }
}
